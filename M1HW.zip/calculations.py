# CTS 285 
# M1HW
# Huy Nguyen
# 08/30/2024

# function add calculation
def add(num1, num2):
    return num1 + num2

# function subtract calculation
def subtract(num1, num2):
    return num1 - num2

# function divide calculation
def divide(num1, num2):
    if num2 != 0:
        return num1 / num2

# function for multiply calculation
def multiply(num1, num2):
    return num1 * num2

# return result base on what math user chose 
def perform_math(choice, num1, num2):
    if choice == '1':
        return add(num1, num2)
    elif choice == '2':
        return subtract(num1, num2)
    elif choice == '3':
        return divide(num1, num2)
    elif choice == '4':
        return multiply(num1, num2)
    else:
        return "Invalid operation"