# CTS 285 
# M1HW
# Huy Nguyen
# 08/30/2024

import calculations

# print menu
def display_menu():
    print("\nWelcome to the calculator program.")
    print("1. Add")
    print("2. Subtract")
    print("3. Divide")
    print("4. Multiply")
    print("5. Exit")

# get input 
def get_user_input():
    num1 = int(input("Enter a number: "))
    num2 = int(input("Enter a number: "))
    return num1, num2

#calcualte function
def calculator_program():
    while True:
        display_menu()
        choice = input("Enter a number: ")

        if choice in ['1', '2', '3', '4']:
            # make list for choice and symbol
            math_name = { '1': 'Add', '2': 'Subtract', '3': 'Divide', '4': 'Multiply' }[choice]
            math_symbol = { '1': '+', '2': '-', '3': '/', '4': '*' }[choice]
            
            # print the 
            print(f"\n{math_name}")
            num1, num2 = get_user_input()
            result = calculations.perform_math(choice, num1, num2)
            
            # print the result using the operator symbol from the dictionary
            print(f"{num1} {math_symbol} {num2} = {"\033[1m"+ str(result) + "\033[0m"}")
            
            # menu for user to do it again or stop the program
            repeat_choice = input("1. Repeat\n2. Main Menu\nEnter a number: ")
            if repeat_choice != '1':
                continue
        
        # stop the program
        elif choice == '5':
            print("Goodbye.")
            break
        
        # for user enter what not in the menu 
        else:
            print("Invalid choice. Please try again.")

# run the program 
if __name__ == "__main__":
    calculator_program()